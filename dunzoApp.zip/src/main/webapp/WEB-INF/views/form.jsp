<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
  <body>
    <h2>Add User</h2>
    <form action="/submit" method="post" enctype="multipart/form-data">
      Name: <input type="text" name="name" required/><br/>
      Email: <input type="email" name="email" required/><br/>
      Profile Image: <input type="file" name="profileImage" accept="image/*" required/><br/>
      <input type="submit" value="Submit"/>
    </form>
    <a href="/view">View All</a>
  </body>
</html>