<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
  <body>
    <h2>Submitted Users</h2>
    <c:forEach items="${users}" var="u">
      <p>Name: ${u.name}</p>
      <p>Email: ${u.email}</p>
      <img src="${u.imagePath}" width="150"/><hr/>
    </c:forEach>
    <a href="/">Add More</a>
  </body>
</html>