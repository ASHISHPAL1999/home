package com.example.dunzoApp.controller;

import com.example.dunzoApp.model.UserData;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

@Controller
public class MainController {
    private static final String UPLOAD_DIR = "src/main/webapp/uploads";
    private List<UserData> users;

    @PostConstruct
    public void init() {
        users = new ArrayList<>();
        new File(UPLOAD_DIR).mkdirs();
    }

    @GetMapping("/")
    public String showForm() {
        return "form";
    }

    @PostMapping("/submit")
    public String submit(@RequestParam String name,
                         @RequestParam String email,
                         @RequestParam MultipartFile profileImage,
                         Model model) throws IOException {

        String fileName = System.currentTimeMillis() + "_" + profileImage.getOriginalFilename();
        Path dest = Paths.get(UPLOAD_DIR, fileName);
        profileImage.transferTo(dest.toFile());

        UserData user = new UserData();
        user.setName(name);
        user.setEmail(email);
        user.setImagePath("uploads/" + fileName);
        users.add(user);

        model.addAttribute("users", users);
        return "view";
    }

    @GetMapping("/view")
    public String viewAll(Model model) {
        model.addAttribute("users", users);
        return "view";
    }
}