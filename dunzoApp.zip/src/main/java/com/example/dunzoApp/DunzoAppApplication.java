package com.example.dunzoApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DunzoAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(DunzoAppApplication.class, args);
    }
}