const express = require('express');
const app = express();
app.get('/api', (req, res) => {
  res.json({ message: 'Secure API is running' });
});
app.listen(3000, () => {
  console.log('Secure API listening on port 3000');
});
