const express = require('express');
const mysql = require('mysql');
const app = express();

const secret = process.env.API_SECRET || 'default-secret';

// No input validation, hardcoded creds, leaking env
const db = mysql.createConnection({
  host: 'vulnerable-mysql',
  user: 'root',
  password: '',
  database: 'testdb'
});

app.get('/api', (req, res) => {
  res.json({
    message: 'Hello from insecure API!',
    exposedSecret: secret,
    mysqlCreds: {
      user: 'root',
      password: ''
    }
  });
});

app.get('/users', (req, res) => {
  db.query('SELECT * FROM users', (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'DB Error', details: err });
    }
    res.json({ users: results });
  });
});

app.listen(3000, () => {
  console.log('Vulnerable API listening on port 3000');
});
