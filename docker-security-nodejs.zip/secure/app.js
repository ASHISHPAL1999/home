const express = require('express');
const app = express();

const dbUser = process.env.DB_USER || 'not set';

app.get('/', (req, res) => {
  res.send(`Welcome! Running securely as ${dbUser}`);
});

app.listen(3000, () => console.log('Secure app running on port 3000'));
