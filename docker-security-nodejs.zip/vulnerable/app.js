const express = require('express');
const app = express();

const dbUser = process.env.DB_USER;
const dbPass = process.env.DB_PASS;

app.get('/', (req, res) => {
  res.send(`Connected to DB as ${dbUser} with password: ${dbPass}`);
});

app.listen(3000, () => console.log('Vulnerable app running on port 3000'));
